function [ new_x, new_y ] = evade(x,y,x0,y0 )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
if y>y0
    y=y+1;
elseif y<y0
    y=y-1;
elseif x<x0
    x=x-1;
elseif x>x0
    x=x+1;
end

new_x=x;
new_y=y;

end

