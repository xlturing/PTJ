
%Game Simulation
%All number is in the unit of cm

close all
%request input file name
fileID=-1;
while fileID==-1
    file_name = input('Input File Name:','s');
    fileID = fopen(file_name);
    if fileID==-1
        fprintf('File name error. Input a valid file Name.\n');
    end
end



%load parameters
data_correct=0;
hash_flag=0;
arg_number=0;
tline=0;
while data_correct==0
    
    tline = fgetl(fileID);
    if tline(1)=='#'
       arg_number=arg_number+1;
       tline = fgetl(fileID);
       switch arg_number
           case 1
               L=cell2mat(textscan(tline,'%.2f'));
           case 2
               R=cell2mat(textscan(tline,'%.2f'));
           case 3
               temp=cell2mat(textscan(tline,'%.2f',2));
               treasure_x=temp(1,1);
               treasure_y=temp(2,1);
           case 4
               anti_cloak_r=cell2mat(textscan(tline,'%d'));
           case 5
               temp=cell2mat(textscan(tline,'%.2f',2));
               escape_x=temp(1,1);
               escape_y=temp(2,1);
           case 6
               TotalTime=cell2mat(textscan(tline,'%d'));
           case 7
               max_entry_time=cell2mat(textscan(tline,'%d'));
           case 8
               thief_sensor_range=cell2mat(textscan(tline,'%d'));
           case 9
               k=cell2mat(textscan(tline,'%d'));
               cop_sensor_range=zeros(1,k,'int8');
       end
       
       if arg_number>9 
           cop_sensor_range(1,arg_number-9)=cell2mat(textscan(tline,'%d'));
       end
    end
    
    if tline==-1
       data_correct=1;
    end
end

%TO DO:
%1. check all the input value is reasonable
%2. check the position of treasure or escape within the box
%


%convert m into cm
L=L*100;
R=R*100;
treasure_x=treasure_x*100;
treasure_y=treasure_y*100;
escape_x=escape_x*100;
escape_y=escape_y*100;


%simulation begin
thief_entry_time=round(rand(1)*single(max_entry_time))+1;
cop_entry_time=round(rand(1,k)*single(max_entry_time))+1;

thief_entry_point=rand(1)*2*pi;
cop_entry_point=rand(1,k)*2*pi;

thief_coor=zeros(1,2);
cop_coor=zeros(1,k,2);
treasure_get_flag=0;
cop_entry_count=0;
Game_end_flag=0;
for step=1:TotalTime
    pause(0.1);
    
    if thief_coor(1,1)==escape_x && thief_coor(1,2)==escape_y && treasure_get_flag~=0
       disp('Thief wins!');
       Game_end_flag=1;
    end
    
    for cop_i=1:k
        if cop_coor(1,cop_i,1)==thief_coor(1,1) && cop_coor(1,cop_i,2)==thief_coor(1,2) && thief_entry_time==0
            disp('Cops win!');
            Game_end_flag=1;
            break;
        end
    end
    
    if Game_end_flag~=0
        break;
    end
        
    if step==1
       game_fig=figure;
       %plot boundary
       plot(-L/2:L/2,-L/2,'linewidth',2,'color','k');
       axis([-L*1.1/2,L*1.1/2,-L*1.1/2,L*1.1/2]);
       grid on
       hold all
       plot(-L/2:L/2,L/2,'linewidth',2,'color','k');
       plot(-L/2,-L/2:L/2,'linewidth',2,'color','k');
       plot(L/2,-L/2:L/2,'linewidth',2,'color','k');
       
       st=sprintf('t=%d',step);
       %set(gca,'title',st)
       
       %plot treasure
       treasure_text=text(treasure_x,treasure_y,'\bullet','fontsize',10,'color','g');
       
       %plot escape
       text(escape_x,escape_y,'\bullet','fontsize',10,'color','y');
       
       %plot circle
       theta=0:0.001:2*pi;
       plot(R*cos(theta),R*sin(theta),'linewidth',1,'color','c');
       
       %detect if thief enter the circle in the first step
       if thief_entry_time==1
          thief_coor=[round(R*cos(thief_entry_point)),round(R*sin(thief_entry_point))];
          thief_text=text(thief_coor(1,1),thief_coor(1,2),'\bullet','fontsize',5,'color','r');
          thief_entry_time=0;%flag for thief entry
       end

    else %for the rest steps
       st=sprintf('t=%d',step);
       %set(gca,'title',st)
       %for thief
       if thief_entry_time~=0
           thief_coor=[round(R*cos(thief_entry_point)),round(R*sin(thief_entry_point))];
           thief_text=text(thief_coor(1,1),thief_coor(1,2),'\bullet','fontsize',5,'color','r');
           thief_entry_time=0;%flag for thief entry
       elseif thief_entry_time==0
           for cop_i=1:k
               if  sqrt((cop_coor(1,cop_i,1)-thief_coor(1,1))^2+(cop_coor(1,cop_i,2)-thief_coor(1,2))^2)<=anti_cloak_r && cop_entry_time(1,cop_i)==0 && treasure_get_flag==0
                   delete(thief_text);
                   [thief_coor(1,1),thief_coor(1,2)]=evade(thief_coor(1,1),thief_coor(1,2),cop_coor(1,cop_i,1),cop_coor(1,cop_i,2));
                   thief_text=text(thief_coor(1,1),thief_coor(1,2),'\bullet','fontsize',5,'color','r');
         
               elseif   sqrt((thief_coor(1,1)-treasure_x)^2+(thief_coor(1,2)-treasure_y)^2)>anti_cloak_r && treasure_get_flag==0
                   delete(thief_text);
                   [thief_coor(1,1),thief_coor(1,2)]=renewxy_random(thief_coor(1,1),thief_coor(1,2),L);
                   thief_text=text(thief_coor(1,1),thief_coor(1,2),'\bullet','fontsize',5,'color','r');
               elseif sqrt((thief_coor(1,1)-treasure_x)^2+(thief_coor(1,2)-treasure_y)^2)<=anti_cloak_r && treasure_get_flag==0
                   if thief_coor(1,1)==treasure_x && thief_coor(1,2)==treasure_y
                       delete(treasure_text);
                       treasure_get_flag=1;
                       [thief_coor(1,1),thief_coor(1,2)]=pursue(thief_coor(1,1),thief_coor(1,2),escape_x,escape_y);
                       delete(thief_text);
                       thief_text=text(thief_coor(1,1),thief_coor(1,2),'\bullet','fontsize',5,'color',[0.82 0.7 0.55]);
                   else
                       [thief_coor(1,1),thief_coor(1,2)]=pursue(thief_coor(1,1),thief_coor(1,2),treasure_x,treasure_y);
                       delete(thief_text);
                       thief_text=text(thief_coor(1,1),thief_coor(1,2),'\bullet','fontsize',5,'color','r');
                   end
               elseif treasure_get_flag~=0
                   [thief_coor(1,1),thief_coor(1,2)]=pursue(thief_coor(1,1),thief_coor(1,2),escape_x,escape_y);
                   delete(thief_text);
                   thief_text=text(thief_coor(1,1),thief_coor(1,2),'\bullet','fontsize',5,'color',[0.82 0.7 0.55]);
               end
           end
       end
             
    end
    
    %cop move
    for cop_i=1:k
        if cop_entry_time(1,cop_i)==0
           if sqrt((cop_coor(1,cop_i,1)-thief_coor(1,1))^2+(cop_coor(1,cop_i,2)-thief_coor(1,2))^2)<=thief_sensor_range
            [cop_coor(1,cop_i,1),cop_coor(1,cop_i,2)]=pursue(cop_coor(1,cop_i,1),cop_coor(1,cop_i,2),thief_coor(1,1),thief_coor(1,2));
           else 
               [cop_coor(1,cop_i,1),cop_coor(1,cop_i,2)]=renewxy_random(cop_coor(1,cop_i,1),cop_coor(1,cop_i,2),L);
           end
           delete(cop_text(1,cop_i));
           cop_text(1,cop_i)=text(cop_coor(1,cop_i,1),cop_coor(1,cop_i,2),'\bullet','fontsize',5,'color','b');
        end
    end
    
    
    
    % cop enter, cop_entry_time = 0 means entered
    for cop_i=1:k
        if thief_entry_time==0 && cop_entry_time(1,cop_i)~=0 && cop_entry_count==cop_entry_time(1,cop_i)
            cop_entry_time(1,cop_i)=0;
            cop_entry_count=0;
            cop_coor(1,cop_i,1)=round(R*cos(cop_entry_point(1,cop_i)));
            cop_coor(1,cop_i,2)=round(R*sin(cop_entry_point(1,cop_i)));
            cop_text(1,cop_i)=text(cop_coor(1,cop_i,1),cop_coor(1,cop_i,2),'\bullet','fontsize',5,'color','b');
        elseif thief_entry_time==0 && cop_entry_time(1,cop_i)~=0
            cop_entry_count=cop_entry_count+1;
            break;
        end
    end
    
    
    
    
end

if Game_end_flag==0
   disp('Game finishes!');
end






