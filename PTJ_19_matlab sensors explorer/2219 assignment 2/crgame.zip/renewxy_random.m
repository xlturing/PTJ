function [new_x, new_y] = renewxy_random(x,y,L)


          Ran_orient=random('unid',4);%1=west, 2=north, 3=east, 4=south
          switch Ran_orient
              case 1
                  x=x-1;
              case 2
                  y=y+1;
              case 3
                  x=x+1;
              case 4
                  y=y-1;
          end
          
         while abs(x)>=round(L/2) || abs(y)>=round(L/2)
            if abs(x)>=round(L/2) && x<0 
               meet_westwall;
            elseif abs(x)>=round(L/2) && x>0
               meet_eastwall;
            end
            
            if abs(y)>=round(L/2) && y<0 
               meet_southwall;
            elseif abs(y)>=round(L/2) && y>0
               meet_northwall;
            end
         end
          
        new_x=x;
        new_y=y;
          
    function meet_westwall
        Ran=random('unid',4);
        switch Ran
            case 1
                x=-round(L/2);
            case 2
                x=-round(L/2);
                y=y+1;
            case 3
                x=-round(L/2)+1;
            case 4
                x=-round(L/2);
                y=y-1;
        end
    end

    function meet_northwall
        Ran=random('unid',4);
        switch Ran
            case 1 %go west
                y=round(L/2);
                x=x-1;
            case 2 %stop
                y=round(L/2);
            case 3 %go east
                y=round(L/2);
                x=x+1;
            case 4 %go south
                y=y-1;
        end
    end
        
    function meet_eastwall
        Ran=random('unid',4);
        switch Ran
            case 1 %go west
                x=x-1;
            case 2 %go north
                x=round(L/2);
                y=y+1;
            case 3 %stop
                x=round(L/2);
            case 4 %go south
                x=round(L/2);
                y=y-1;
        end
    end

    function meet_southwall
        Ran=random('unid',4);
        switch Ran
            case 1 %go west
                y=-round(L/2);
                x=x-1;
            case 2 %go north
                y=y+1;
            case 3 %go east
                y=-round(L/2);
                x=x+1;
            case 4 %stop
                y=-round(L/2);
        end
    end


end

